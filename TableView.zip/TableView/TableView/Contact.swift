//
//  Contact.swift
//  TableView
//
//  Created by Marc Atienza on 12/2/23.
//

import Foundation

struct Contact {
    var name: String
    var initials: String
    
    init(_ name: String, _ initials: String) {
        self.name = name
        self.initials = initials
    }
    
}
