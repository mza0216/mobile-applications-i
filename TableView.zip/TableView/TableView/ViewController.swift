//
//  ViewController.swift
//  TableView
//
//  Created by Marc Atienza on 12/2/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var selectedIndexPath: IndexPath?
    
    var contacts = [
        Contact("Michael Scott","MS"),
        Contact("Dwight Schrute", "DS"),
        Contact("Jim Halpert", "JH"),
        Contact("Pam Beesly", "PB"),
        Contact("Kelly Kapoor", "KK"),
        Contact("Andy Bernard", "AB"),
        Contact("Angela Martin", "AM"),
        Contact("Ryan Howard", "RH"),
        Contact("Stanley Hudson", "SH"),
        Contact("Toby Flenderson", "TF"),
    ]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
        var content = cell.defaultContentConfiguration()
        content.text = contacts[indexPath.row].name
        content.secondaryText = contacts[indexPath.row].initials
        cell.contentConfiguration = content
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedIndexPath = indexPath
        performSegue(withIdentifier: "toNavigation", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toNavigation" {
            
            if let indexPath = selectedIndexPath {
                
                let selectedContact = contacts[indexPath.row]
                
                if let output = segue.destination as? NavigationViewController {
                    output.selectedPersonName = selectedContact.name
                }
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

