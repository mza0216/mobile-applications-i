//
//  NavigationViewController.swift
//  TableView
//
//  Created by Marc Atienza on 12/3/23.
//

import UIKit

class NavigationViewController: UIViewController {
    
    var selectedPersonName : String?
    
    @IBOutlet weak var callLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let name = selectedPersonName {
            callLabel.text = "Call: \(name)"
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
