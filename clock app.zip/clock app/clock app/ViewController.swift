//
//  ViewController.swift
//  clock app
//
//  Created by Marc Atienza on 11/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var backgroundImageView: UIImageView!
    @IBOutlet weak var dateTime: UILabel!
    
    @IBOutlet weak var setTime: UIDatePicker!
    @IBOutlet weak var timeLeft: UILabel!
    @IBOutlet weak var startStop: UIButton!
    
    var timer: Timer?
    var remaining: TimeInterval = 0
    var isRunning = false

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "EEEE, d MMMM yyyy hh:mm:ss a"
        
        let currentDateTime = dateFormat.string(from: Date())
        dateTime.text = currentDateTime
        
        let calendar = Calendar.current
        
        Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        
        if let hour = calendar.dateComponents([.hour], from: Date()).hour {
            
            if hour < 12 {
                backgroundImageView.image = UIImage(named: "sun_logo")
            } else {
                backgroundImageView.image = UIImage(named: "moon_logo")
            }
        }
    }
    
    @objc func updateTime() {
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "EEEE, d MMMM yyyy hh:mm:ss a"
        let currentDateTime = dateFormat.string(from: Date())
        dateTime.text = currentDateTime
    }
    
    @IBAction func startStopTimer(_ sender: UIButton) {
        if isRunning {
            timer?.invalidate()
            timer = nil
            isRunning = false
            startStop.setTitle("Start Timer", for: .normal)
        } else {
            remaining = setTime.countDownDuration
            startTimer()
            isRunning = true
            startStop.setTitle("Stop Timer", for: .normal)
        }
    }
    
    func startTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updatedTime), userInfo: nil, repeats: true)
    }
    
    @objc func updatedTime() {
        if remaining > 0 {
            remaining -= 1
            let hours = Int(remaining) / 3600
            let minutes = (Int(remaining) % 3600) / 60
            let seconds = Int(remaining) % 60
            
            timeLeft.text = String(format: "Time Remaining: %02d:%02d:%02d", hours, minutes, seconds)
        } else {
            timer?.invalidate()
            timer = nil
            isRunning = false
            startStop.setTitle("Start Timer", for: .normal)
        }
    }


}

