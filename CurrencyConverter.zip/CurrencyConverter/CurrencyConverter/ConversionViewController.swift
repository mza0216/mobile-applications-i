import UIKit

class ConversionViewController: UIViewController {
    
    @IBOutlet weak var euroLabel: UILabel!
    @IBOutlet weak var pesoLabel: UILabel!
    @IBOutlet weak var gbpLabel: UILabel!
    @IBOutlet weak var jpyLabel: UILabel!
    
    @IBOutlet weak var usdLabel: UILabel!
    
    @IBOutlet weak var currency1: UILabel!
    @IBOutlet weak var currency2: UILabel!
    
    @IBOutlet weak var currency3: UILabel!
    
    @IBOutlet weak var currency4: UILabel!
    
    var amountInUSD : Double = 0
    var currencies : [Currency] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        convertAndDisplay()
    }
    
    private func convertAndDisplay() {
        usdLabel.text = String(amountInUSD)
        if currencies.contains(.Euro) {
            euroLabel.text = convertCurrency(to: .Euro)
        } else {
            euroLabel.text = ""
            currency1.text = ""
        }
        if currencies.contains(.Peso) {
            pesoLabel.text = convertCurrency(to: .Peso)
        } else {
            pesoLabel.text = ""
            currency2.text = ""
            }
        if currencies.contains(.GBP) {
            gbpLabel.text = convertCurrency(to: .GBP)
        } else {
            gbpLabel.text = ""
            currency3.text = ""
            }
        if currencies.contains(.JPY) {
            jpyLabel.text = convertCurrency(to: .JPY)
        } else {
            jpyLabel.text = ""
            currency4.text = ""
            }
    }
    
    private func convertCurrency(to currency: Currency) -> String {
        return "\(amountInUSD * conversionRate(to: currency))"
    }
    
    private func conversionRate(to currency: Currency) -> Double {
        switch currency {
            case .Euro: return 0.91
            case .Peso: return 17.11
            case .GBP: return 0.79
            case .JPY: return 110.0
        }
    }
}
