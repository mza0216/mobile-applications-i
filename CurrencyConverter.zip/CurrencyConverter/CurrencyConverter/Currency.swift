import Foundation

enum Currency : String {
    case Euro
    case Peso
    case GBP
    case JPY
}
