import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var amountText: UITextField!
    @IBOutlet weak var euroSwitch: UISwitch!
    @IBOutlet weak var pesoSwitch: UISwitch!
    @IBOutlet weak var gbpSwitch: UISwitch!
    @IBOutlet weak var jpySwitch: UISwitch!
    
    @IBOutlet weak var errorMessage: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        errorMessage.isHidden = true
    }

    @IBAction func convertButton(_ sender: UIButton) {
        guard let amountUSD = amountText.text, let amount = Int(amountUSD) else {
            errorMessage.isHidden = false
            errorMessage.text = "Invalid input entered. Enter an Integer."
            return
        }
        errorMessage.isHidden = true
        self.performSegue(withIdentifier: "showConversion", sender: amount)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showConversion" {
            if let destinationVC = segue.destination as? ConversionViewController, let amount = sender as? Int {
                destinationVC.amountInUSD = Double(amount)
                destinationVC.currencies = getCurrencies()
            }
        }
    }
    
    private func getCurrencies() -> [Currency] {
        var selectedCurrencies : [Currency] = []
        
        if euroSwitch.isOn {
            selectedCurrencies.append(.Euro)
        } 
        if pesoSwitch.isOn {
            selectedCurrencies.append(.Peso)
        }
        if gbpSwitch.isOn { 
            selectedCurrencies.append(.GBP)
        }
        if jpySwitch.isOn { 
            selectedCurrencies.append(.JPY)
        }
        
        return selectedCurrencies
    }
    
}

